<?php
	include("check.php");	
?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>New product</title>
  
      <link rel="stylesheet" href="css/cust.css">

  
</head>

<body>

  <div class="container">  
  <form id="contact" action="product-add.php" method="POST" enctype="multipart/form-data">
    <h2>Add New Product</h2>
    <fieldset>
      <input placeholder="Enter Product Name" name="p_name" type="text" tabindex="1" required autofocus>
    </fieldset>
    <fieldset>
      <input class="pri" placeholder="Enter Product Price" name="p_price" type="number" tabindex="2" required>
    </fieldset>
    <fieldset>
      <input placeholder="Enter Product Code" name="p_code" type="text" tabindex="3" >
    </fieldset>
	 <fieldset>
      <input placeholder="Enter Product Size" name="p_size" type="Text" tabindex="4" required>
    </fieldset>
	<fieldset>
      Product In Stock<select name ="stock"> <option name="stock" value="1">Yes </option> <option name="stock" value="0">No </option></select>
    </fieldset>
	<fieldset>
      <input placeholder="Enter Product Discount" name="p_discount" type="number" tabindex="3" >
    </fieldset>
   
    <fieldset>
      <textarea placeholder="Enter Product description...." name="p_detail" tabindex="5" required></textarea>
    </fieldset>
    <fieldset>
	 <fieldset>
      <input  name="p_image" type="file"  required>
    </fieldset>
      <button name="submit" type="submit" name="submit" id="contact-submit">Save</button>
    </fieldset>
 
  </form>
</div>
  
  
</body>
</html>
