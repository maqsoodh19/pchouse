<?php
include("check.php");	// session check

if(isset($_POST['submit'])){
$code ="N/A";
$name = $_POST['p_name'];
$price = $_POST['p_price'];
$code = $_POST['p_code'];
$size = $_POST['p_size'];
$stock = $_POST['stock'];
$discount = $_POST['p_discount'];
$detail = $_POST['p_detail'];

    //   File Upload
    $file = rand(1000,100000)."-".$_FILES['p_image']['name'];
    $file_loc = $_FILES['p_image']['tmp_name'];
	$folder="../uploads/";
	// new name of file
	$new_file_name = strtolower($file);
	//convering into small alphabetics
	$final_file=str_replace(' ','-',$new_file_name);
	
	if(move_uploaded_file($file_loc,$folder.$final_file)) //uploading file into folder 
	{
		
		$q1= "INSERT INTO `tblproducts` ( `productName`, `productPrice`, `productCode`, `productInStock`,
        `productDiscount`, `productSizes`, `productDetails`,`file`) VALUES ('$name', '$price', '$code', '$stock', '$discount', '$size', '$detail','$final_file');";

     $result = mysqli_query($db,$q1);
     if($result)
      {
	    ?>
	  <form style="margin-left:35%;margin-top:10%;background-color:grey; width:300px; padding: 1%" action="home.php">
	   <p> Data Successfully Saved </p>
	
	   <button type="submit" >Done </button>
	   </form>
	   <?php
          }
      else  // if data is not inserted into database
	  {
          ?>
	     <form style="margin-left:35%;margin-top:10%;background-color:grey; width:300px; padding: 1%" action="add-product-index.php">
	       <p> Data Successfully Not Saved </p>
	       <button type="submit">Try again!</button>
	         </form>
             <?php 
	       }
	   
	   
	}	
	
	else // if error occured in uloading file
	  {
			?>
		      <form style="margin-left:35%;margin-top:10%;background-color:grey; width:300px; padding: 1%" action="add-product-index.php">
	          <p> error while uploading image </p>
	
	           <button type="submit" >Go Back </button>
	            </form>
		    <?php  
	    }
	




}

else //if data is not inserted through submit form
{
	?>
	<form style="margin-left:35%;margin-top:10%;background-color:grey; width:300px; padding: 1%" action="add-product-index.php">
	<p> Require all the fields </p>
	
	<button type="submit" >Go Back! </button>
	</form>
<?php  mysqli_close($db);
}
?>