<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'pchouse');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

if(!$db)
{
	die('Error in connecting with database!!!!!! ');
	
}

$select = mysqli_select_db($db,DB_DATABASE);
if(!$select)
{
	die('Error in selecting databse!!!!! ');
}

?>