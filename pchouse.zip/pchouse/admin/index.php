<?php
	include('login.php'); // Include Login Script

	if ((isset($_SESSION['username']) != '')) 
	{
		header('Location: home.php');
	}	
	

?>

<!DOCTYPE html>
<html>

<head>


  <title>Admin Login </title>
<style>

body {
	background: #448ed3 ;
	font-family: "Lato" ;
}
.wrap {
	width:300px;
	height: auto;
	margin: auto;
	margin-top: 9%;
	box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.title h1,.wrap input {
	border: none;
	background: #fff;
  font-family:Lato ;
  font-weight:700 ;
	display: block;
	height: 40px;
	outline: none;
	width: calc(100% - 24px) ;
	margin: auto;
	padding: 6px 12px 6px 12px;
}
.error
{
	width: 100%;
	color:red;
	font-family:Consolas, "Andale Mono", "Lucida Console", "Lucida Sans Typewriter", Monaco, "Courier New", monospace;
	font-size:16px;
	margin-bottom: 30px;
}


.wrap #bt {
	width: 100%;
	border-radius: 7px;
	background: #b6ee65;
	text-decoration: center;
	color: #51771a;
     margin-top:-5px;
	padding-top: 14px;
	padding-bottom: 14px;
	outline: none;
	font-size: 13px;	
	border-bottom: 3px solid #307d63;
	cursor: pointer;
}
</style>

</head>

<body>

  <div class="wrap">
  <div class="title"> <h1 align="center"> Admin Account </h1> </div>
		<form method="post" action="index.php">
		<div align="center" class="error" > <?php echo $error;?> </div>
		<input name="username" type="text"  size="25" placeholder="username" required />
		<input name="password" type="password" placeholder="password" required />
		<input id="bt" type="submit" name="submit" value="Login!" />
		
		</form>
	</div>

 

</body>

</html>