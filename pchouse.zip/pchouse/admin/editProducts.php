<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Products</title>
</head>
<style>
table {
	border-color:black;
	margin-left:%;
	padding:0%;

}

td{
	height:100%;
	text-align:center;
}
input{
	height: 30%;
	text-align:center;
	border:1px solid #0788ff;
}
textarea{
	height:100%;
	text-align:center;
}
select,option{
	width:100%;
	height:37px;
	align:center;
} 



input[type='file']{ width:190px}
</style>

<script type='text/javascript'>
function confirmDelete()
{
   return confirm("Are you sure you want to delete this?");
}
</script>

<body>

<?php
	if(isset($_POST['delete']))  // delete operation
    {
	
	$res=mysqli_query($db,"SELECT file FROM `tblproducts` where `productId`=$_POST[hidden]");
      $row=mysqli_fetch_array($res);                                                          // selecting image path from database
	  $dq=" DELETE FROM `tblproducts` where `productId`=$_POST[hidden]  ";
	  mysqli_query($db,$dq);
                                            
      unlink("../uploads/".$row['file']); 
	
	  ?> 
		<script>
		alert('successfully Deleted');
         window.location.href='editProducts.php';
        </script>
		<?php
	}	// end of delete
	
  if(isset($_POST['update']))  // update info
   {  
     if($_FILES['new_image']['size'] >0) // updating new image
	 {
		 
		$res=mysqli_query($db,"SELECT file FROM `tblproducts` where `productId`=$_POST[hidden]");
      $row=mysqli_fetch_array($res);                                                          // selecting image path from database
	//  $dq=" DELETE FROM `tblproducts` where `productId`=$_POST[hidden]  ";
	//  mysqli_query($db,$dq);
                                            
      unlink("../uploads/".$row['file']); 
		 
		  //   File Upload
    $file = rand(1000,100000)."-".$_FILES['new_image']['name'];
    $file_loc = $_FILES['new_image']['tmp_name'];
	$folder="../uploads/";
	// new name of file
	$new_file_name = strtolower($file);
	//convering into small alphabetics
	$final_file=str_replace(' ','-',$new_file_name);
	
	                                                     //uploading file into folder 
		 
		 if( move_uploaded_file($file_loc,$folder.$final_file)){                               // if image successfully uploads
		 $q=" UPDATE `tblproducts` SET `file`='$final_file' where `productId`=$_POST[hidden] ";
		 mysqli_query($db,$q) ?>
		<script>
		alert('successfully updated image');
        window.location.href='editProducts.php';
        </script>
		<?php } 
		 
	 }
	 
	$dq="UPDATE `tblproducts` SET `productName`='$_POST[name]',`productPrice`='$_POST[price]',`productCode`='$_POST[code]',`productInStock`='$_POST[stock]',`productDiscount`='$_POST[discount]',`productSizes`='$_POST[size]',`productDetails`='$_POST[details]' where `productId`=$_POST[hidden]";  
	
	
	 $result=  mysqli_query($db,$dq);
	 if($result){                         // if update successfully
		 ?>
		<script>
		alert('successfully updated');
        window.location.href='editProducts.php';
        </script>
		<?php
	            }
	 else{
		 ?>
		<script>
		alert('error while updating info. try again!!!!');
        window.location.href='editProducts.php';
        </script>
		<?php
	 }
     
	} // end of update

$q1="select *from `tblproducts`";  // display all products
$fetch=mysqli_query($db,$q1);

echo "<table border =1>

    <tr >

	<th> Product Image </th>
      <th> Product Name </th>
	  <th> Product Price</th>
	  <th> Product Code</th>	   
	   <th> Product In stock </th>
	   <th>Product Discount %</th>
	  <th> Product size </th>
	  <th> Product Dtails </th>
	   <th colspan =4 > Action </th>
    </tr> ";
  

while($row = mysqli_fetch_assoc($fetch))
{
	
	echo "<form action=editProducts.php method=POST enctype= multipart/form-data >";
	echo "<tr>";
            ?>	   
	<td> <p><img src="../uploads/<?php echo $row['file'] ?>" style="max-height:70px;" /></p>
	<input  type="file" name="new_image" accept="image/*" id="file" class="inputfile"/> </td>
	<td> <input type="text" name="name" value="<?php echo$row['productName'];?> " > </td> 
<?php echo"<td>". "<input type=number name=price value= " .$row['productPrice']."></td>";
	echo"<td>". "<input type=text name=code value= " .$row['productCode'] ."></td>"; ?>
	<td> <select name ="stock"> <option <?php if(!$row["productInStock"] ){ echo"selected"; }?> value="1">Avaible </option> 
	<option <?php if(!$row["productInStock"] ){ echo"selected"; }?> value="0"> Not Avaible </option></select> </td>
<?php	echo"<td>" . "<input type=number name= discount value= " .$row['productDiscount']."></td>";?>
	<td> <input type="text" name="size" value="<?php echo$row["productSizes"];?>"> </td> 
	<td> <textarea type="text" name="details" value= " <?php echo $row["productDetails"]; ?> "><?php echo $row["productDetails"]; ?> </textarea>   </td>
  <?php  echo"<td>" . "<input type=hidden name=hidden value=" . $row['productId'] . "></td>"; ?>
	<td><input type="submit" name='delete' value='Delete' onclick='return confirmDelete()'> </td> <?php
	echo"<td>" . "<input type=submit name=update value=update". "></td>";
	echo "</tr>";
	
	echo"</form>";
	}
	echo "</table>"
        


?>
</body>
</html>