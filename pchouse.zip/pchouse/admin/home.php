<?php
	include("check.php");	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>


    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/font-awesome.min.css" rel="stylesheet">
	
	
   <!-- Custom style sheet -->
   <style>
   body{
	   margin-left:3%;
	   margin-right:3%;
	   
   }
   .welcome{
	   width: 100%;
	   height: 200px;
	   background-color: grey;
	   font-family: "Times New Roman", Times, serif;
	   color: white;
	   text-align:center;
	   padding:2%;
	   margin-top:0%;
	   
   }
   </style>
   
</head>

<body>
<div class="welcome"> <h1 class="hello">Welcome , <em><?php echo $login_user;?>!</em></h1>
 <a href="logout.php" class="btn btn-default btn-lg">
  <span class="glyphicon glyphicon-log-out"></span> Log out </a></div>
  </br>
  </br>
  <div style= "margin-left:10%"> <h2> Manage Product Module </h2> </div>
<nav class="navbar navbar-inverse" style="width:50%;margin-left:10%" >
  <div class="container-fluid">
    <div class="navbar-header">
	
     <ul class="nav navbar-nav navbar-middle" >
      <li><a href="index.php"> Admin</a>  </li>
      <li><a href="add-product-index.php">New Product</a></li>
      <li><a href="editProducts.php">Update Products</a></li>
	   <li><a href=""></a></li>
    </ul>
	

  </div> </nav>
</body>
</html>