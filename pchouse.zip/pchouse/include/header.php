			
<header class="header_container ">
<div class="site_logo">
  <img src="title.png" alt="" style="max-width: 80%;max-height:80%;" /> </div>

  <div class="company-social">
                    <ul class="frame">  
                        <li class="social-facebook"><a href="https:www.facebook.com/hassan3161" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li class="social-twitter"><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li class="social-dribble"><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
                        <li class="social-google"><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
					</div>
</header>

<!--------------- Menu section ------------------>



<nav class="navbar navbar-inverse" >
  <div class="container-fluid">
    <div class="navbar-header">
    <button class="navbar-toggle" data-toggle ="collapse" data-target = ".navHeaderCollapse">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	</button>  <a class="navbar-brand" href="index.php">PC HOUSE</a></div>
	<div class="collapse navbar-collapse navHeaderCollapse" >
	
     <ul class="nav navbar-nav navbar-middle" >
      <li><a href="index.php"> Home</a>  </li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="product.php">Products</a></li>
      <li><a href="contact.php">Contact Us</a></li>
    </ul>
	
	</div>
  </div> </nav>