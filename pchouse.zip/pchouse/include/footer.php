   
	<footer class="footer" id="footer">
		<div class="row">
		
				<div class="col-md-12">
					<p>© All rights reserved - Developed by  <a href="http://localhost/portfalio/" target="_blank">Maqsood Studios</a></p>				</div>
			</div>	
	</footer>