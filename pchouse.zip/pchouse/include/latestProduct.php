  



  <div class="row text-center">
<?php
      include('admin/connection.php');
 $q ="SELECT * FROM `tblproducts`";
 $result =mysqli_query($db,$q);
  $count=0;
 while($row = mysqli_fetch_array($result) AND $count!=4 ){
  $id = $row['productId'];
  //echo $count;
  ?>
      <div class="col-md-3 col-sm-6 hero-feature ">
                <div class="thumbnail "> <?php
                 echo"   <img src='uploads/".$row['file']."' alt='images' style= 'max-height:180px' >"; ?>
                    <div class="caption">
                     <h3> <?php   echo $row['productName'] ?> </h3>
						<h4>Rs. <?php   echo $row['productPrice'] ?>/- </h4>
                       <p> <?php   echo $row['productDetails'] ?> </p>

                        <p>
                         <form action="product-detail.php" method ="POST" target="_blank"> <input type="hidden"  name="id" value="<?php echo $id; ?>" />
						 <button type="submit" class="btn btn-default">More Info </button> </form>
                        </p>
                    </div>
                </div>
            </div>
			
   <?php  $count++;
 }   // while loop end
      ?> 
      
        </div>
        <!-- /.row -->