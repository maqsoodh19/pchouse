<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>about Page</title>

	
    <!-- Bootstrap -->
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link href="css/half-slider.css" rel="stylesheet">
	 
	<style>
	[class*="col-"]{
    margin-bottom: 0px;
    padding-bottom: 0px;
              }
	</style>
	
	
   
  </head>
  <body>
            <!--------------- Site logo and Social icon section ------------------>
			
			<?php
include('include/header.php');

?>
  
 <!-- Contact Page Start -->
<div class="jumbotron" style="padding:15px 0px 15px 0px;">
  <div class="container">
   <div class="row text-center" style="margin-bottom:5%;">
      <div class="col-md-4">
	  <img src="image/shop-pic.jpg" class="img-rounded" alt="shop image" width="1150" height="500">
	  </div>
	  </div>
	  <div class="row">
     <div class="col-md-12 col-sm-12 info text-center">
	  <div > <h2><strong> About Us! </strong></h2> </div>
	    <p>The Computer Shop is dedicated to providing fast and reliable computer support and personalized attention to our customers. We take pride in providing optimal solutions that over-achieve our customers technical needs. What separates us from our competitors is fast turnaround. Along with highly technical backgrounds, we have genuine love for technology and eagerness to find your solution. Experiencing computer problems may be frustrating, but we take joy in easing your concerns and issues. We look forward to taking care of you and all of your technical issues, questions, and projects. </p>
	 </div>
   </div>
  </div>
</div>

<!-- /Section: contact -->
    
	<?php
 include('include/footer.php');  ?>
	
<!--------- Java Script ---->



<script src="css/jquery.min.js"></script>
	<script src="css/bootstrap.min.js"></script>
</body>
</html>