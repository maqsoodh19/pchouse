<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>produt Page</title>

    <!-- Bootstrap -->
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
   
  </head>
  <body>
            <!--------------- Site logo and Social icon section ------------------>
			<?php
include('include/header.php');

?>
  
  
 <!-- Product views -->
 <div class="jumbotron " style="margin-top:0; ">
<div class="container" >

 <?php
 
 include('admin/connection.php');
 $q ="SELECT * FROM `tblproducts`";
 $result =mysqli_query($db,$q);
  
  $count=4;   // start new row after 4 div
  $count2=0;
  
  
 while($row = mysqli_fetch_array($result)){
  $id = $row['productId'];
  if($count%4==0)
  { 
	   ?> <div class="row text-center"> <?php
	  
  }
  //echo $count;
  ?>
      <div class="col-md-3 col-sm-6 hero-feature " style="min-width:200px">
                <div class="thumbnail "> <?php
                 echo"   <img src='uploads/".$row['file']."' alt='images' style= 'max-height:180px' >"; ?>
                    <div class="caption">
                     <h3> <?php   echo $row['productName'] ?> </h3>
						<h4>Rs. <?php   echo $row['productPrice'] ?>/- </h4>
                       <p> <?php   echo $row['productDetails'] ?> </p>

                        <p>
                         <form action="product-detail.php" method ="POST" target="_blank"> <input type="hidden"  name="id" value="<?php echo $id; ?>" />
						 <button type="submit" class="btn btn-default">More Info </button> </form>
                        </p>
                    </div>
                </div>
            </div>
			
   <?php  $count2++;
   if($count2%4==0){
    ?> </div> <?php }
   $count++;   
 }   // while loop end
       if($count2%4!=0){
    ?> </div> <?php }
        ?>
         
		   </div> <!--- container end ---->
 
 </div>  <!--- jumbo end ---->
		 

<!-- /Section: footer -->
  
	<?php
        include('include/footer.php');  ?>
     
	
	
<!--------- Java Script ---->
 

<script src="css/jquery.min.js"></script>
	<script src="css/bootstrap.min.js"></script>
</body>
</html>