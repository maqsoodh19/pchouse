<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Home Page</title>

	
    <!-- Bootstrap -->
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link href="css/half-slider.css" rel="stylesheet">
	 
	<style>
	[class*="col-"]{
    margin-bottom: 0px;
    padding-bottom: 0px;
              }
	</style>
	
	
   
  </head>
  <body>
            <!--------------- Site logo and Social icon section ------------------>
			<?php
include('include/header.php');
 include('admin/connection.php');
 
 $id =$_POST['id'];
 $q ="SELECT * FROM `tblproducts` where productId='$id'";
 $result =mysqli_query($db,$q);
  
 $row = mysqli_fetch_assoc($result)
?>
  
  
 <!-- Product Details Page Start -->
<div class="jumbotron">
  <div class="container">
    <div class="row text-center">
        <div class="col-md-6 col-sm-6 hero-feature">
                <div class="thumbnail">
                    <img src="uploads/<?php echo $row['file'] ?>" alt="" style="">
                </div>
            </div>   <!--- end of product div- pic -->
	<div class="col-md-5 col-sm-6 col-md-offset-1 header-table-box ">
		<div class="table">
	    <table class="text-center ">
		  <tr> <td><h2>Name </h2></td> <td><h2><?php echo $row['productName'] ?> </h2></td>
		  <tr> <td><h2>Price </h2></td> <td><h2> Rs. <?php echo $row['productPrice'] ?>/- </h2></td>
		  <tr> <td><h2>Details</h2> </td> <td><h4><?php echo $row['productDetails'] ?></h4> </td> 
		</table>
	   </div>
	</div>
	   
	</div> <!-- end of first row  --->
	   <div class="row text-center" style="margin:0;width:100%">
	       <div class="col-md-12 col-sm-12 table-responsive table-box hero-super">
		      <table class="info-table text-center"><tbody><tr>
			  <th><h2>Description</h2></th><th style="text-align:center"><h2><?php echo $row['productName'] ?></h2></th></tr>
			  <tr><td>Product Code</td><td><div><?php echo $row['productCode'] ?></div></td></tr>
			  <tr><td>Product In stock</td><td><div><?php if($row['productInStock']){echo "Availabe";} else{echo "Out Of Stock";} ?></div></td></tr>
			  <tr><td>Discount on Product </td><td><div><?php echo $row['productDiscount']."%";?></div></td></tr>
			  <tr><td>Dimensions</td><td><div><?php echo $row['productSizes'] ?></div></td></tr>

			  
			
			 
			  <tr><td>WLAN</td><td><div>WiFi 2 x 2 802.11 a/c + Bluetooth<sup>®</sup> 4.0</div></td></tr>
			 
			  </tbody></table>
	        </div>
	   </div>
	  
  </div>   
 </div>   <!-----end of jumbo ----->
                  

<!-- /Section: contact -->
    
	<footer class="footer" id="footer">
		<div class="row">
		
				<div class="col-md-12">
					<p>© All rights reserved - Developed by  <a href="E:\Maqsood ul Hassan\6th Semester\Web Eng\portfalio\index.html" target="_blank">Maqsood Studios</a></p>				</div>
			</div>	
	</footer>
	
<!--------- Java Script ---->


  <script>
    $('.carousel').carousel({
        interval: 3000 //changes the image slider slide speed   
    })
    </script>

<script src="css/jquery.min.js"></script>
	<script src="css/bootstrap.min.js"></script>
</body>
</html>