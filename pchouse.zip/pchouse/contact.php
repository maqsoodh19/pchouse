<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Contact Page</title>

	
    <!-- Bootstrap -->
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
	<link href="css/half-slider.css" rel="stylesheet">
	 
	<style>
	[class*="col-"]{
    margin-bottom: 0px;
    padding-bottom: 0px;
              }
	</style>
	
	
   
  </head>
  <body>
            <!--------------- Site logo and Social icon section ------------------>
			<?php
include('include/header.php');

?>
  
 <!-- Contact Page Start -->
<div class="jumbotron contact-box">
  <div class="container">
    <div class="row">
             <!-- Form Box start-->
      <div class="col-md-6  col-sm-6">
        <div class="well well-sm form-section">
          <form class="form-horizontal" action="" method="post">
          <fieldset>
            <legend class="text-center "style="color:#bebebe; border-bottom-color:rgba(0,0,0,0.2);">Contact us</legend>
    
            <!-- Name input-->
            <div class="form-group">
              <label class="col-md-3 control-label" for="name">Name</label>
              <div class="col-md-9">
                <input id="name" name="name" type="text" placeholder="Your name" class="form-control">
              </div>
            </div>
    
            <!-- Email input-->
            <div class="form-group">
              <label class="col-md-3 control-label" for="email">Your E-mail</label>
              <div class="col-md-9">
                <input id="email" name="email" type="text" placeholder="Your email" class="form-control">
              </div>
            </div>
    
            <!-- Message body -->
            <div class="form-group">
              <label class="col-md-3 control-label" for="message">Your message</label>
              <div class="col-md-9">
                <textarea class="form-control" id="message" name="message" placeholder="Please enter your message here..." rows="5"></textarea>
              </div>
            </div>
    
            <!-- Form actions -->
            <div class="form-group">
              <div class="col-md-12 text-right">
                <button type="submit" class="btn btn-primary btn-lg">Submit</button>
              </div>
            </div>
          </fieldset>
          </form>
        </div>
      </div>
	         <div class="col-md-4 col-md-offset-2 col-sm-6  info">
	               <h2>PC HOUSE</h2>
							<p>
								<span>Address:</span> 123, XYZ.
							</p>
							<p>
								<span>Telephone Number:</span> XYZ
							</p>
							<p>
								<span>Email:</span> xyz@pchouse.com
							</p>
              </div>
              <div class="col-md-4 col-md-offset-2 col-sm-6 info" style="padding:1%">
			    <div id="googleMap" style="height:410px;width:365px;"></div>
              </div>			  

      
	</div>
  </div>
</div>

<!-- /Section: contact -->
    
<?php
 include('include/footer.php');  ?>
	
<!--------- Java Script ---->
<script>
function myMap() {
var myCenter = new google.maps.LatLng(31.4698656,74.2414736,18.87);
var mapProp = {center:myCenter, zoom:12, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
var marker = new google.maps.Marker({position:myCenter});
marker.setMap(map);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBcaF4DLDHdyLoazqswn8nA-jzBcXnakE0&callback=myMap"></script>
</script>

<script src="css/jquery.min.js"></script>
	<script src="css/bootstrap.min.js"></script>
</body>
</html>