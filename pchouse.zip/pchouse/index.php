<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Home Page</title>

	
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/half-slider.css" rel="stylesheet">
	
   <!-- Custom style sheet -->
   <link href="css/custom.css" rel="stylesheet">
	
	
	
   
  </head>
  <body>
            <!--------------- Site logo and Social icon section ------------------>
			<?php
include('include/header.php');

?>
  
  
 <!-- /Banner Slider -->
 <header id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
			<li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>
  <div class="carousel-inner">
            <div class="item active">
                <!-- Set the first background image using inline CSS below. -->
                <div class="fill" style="background-image:url('image/0.jpg');"></div>
                <div class="carousel-caption">
                    <h2></h2>
                </div>
            </div>
            <div class="item">
                <!-- Set the second background image using inline CSS below. -->
                <div class="fill" style="background-image:url('image/1.jpg');"></div>
                <div class="carousel-caption">
                    <h2></h2>
                </div>
            </div>
            <div class="item">
                <!-- Set the third background image using inline CSS below. -->
                <div class="fill" style="background-image:url('image/2.jpg');"></div>
                <div class="carousel-caption">
                    <h2></h2>
                </div>
            </div>
			 <div class="item">
                <!-- Set the third background image using inline CSS below. -->
                <div class="fill" style="background-image:url('image/3.jpg');"></div>
                <div class="carousel-caption">
                    <h2></h2>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
		</header>


<!-- /Section: content -->

   <div class="container page_content">

        <!-- Jumbotron Header -->
		
        <header class="jumbotron hero-spacer text-center">
           <div id="heading1"> <h2><strong> WELCOME </strong></h2> </div>
            <p>MEET PC House! - a new site to help you get the most out of your tech, so you can get the most out of your life. We offer affordable Laptop according to your budget, because technology should make your life easier, not more complicated.</p>
          
        </header> 


        <!-- Title -->
        <div class="row">
            <div class="col-lg-12">
                <h3>Latest Products</h3>
            </div>
        </div>
        <!-- /.row -->

        <!-- Page Features -->
     <?php
	 include('include/latestProduct.php');
	       ?>


    </div>

<!-- /Section: contact -->
<?php
 include('include/footer.php');  ?>
	
<!--------- Java Script ---->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  
  <script>
    $('.carousel').carousel({
        interval: 3000 //changes the image slider slide speed   
    })
    </script>


</body>
</html>